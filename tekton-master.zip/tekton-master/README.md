Tekton
================

A full stack project for Google App Engine based on modules Tekton-micro, Gaegraph, Gaeforms and Gaepermission, Jinja2 and Babel

This application is running on https://tekton-fullstack.appspot.com

Provisory running pt_BR on https://pt-dot-tekton-fullstack.appspot.com
